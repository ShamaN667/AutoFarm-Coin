
#!/bin/bash
python3 autobonus_1.py &
python3 autobonus_2.py &
wait
